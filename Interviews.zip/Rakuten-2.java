Rakutan-2
--------
95th
-----

db migration architecture?
how to handle duplicate records being added to DB?
how to handle data lost during db failure?
how to reduce db calls if data is permenant most of the time?

